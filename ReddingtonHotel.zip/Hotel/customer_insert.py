#!/usr/bin/python
# -*- coding: utf-8 -*-

import cgi
import _mysql
import sys
import ConfigParser
import MySQLdb


form=cgi.FieldStorage()
cname=form.getvalue('ccname','0')
pno=form.getvalue('pno','0')
guestno=form.getvalue('guestno','0')
sdate=form.getvalue('sdate','2012-01-01')
edate=form.getvalue('edate','2012-01-01')
rType=form.getvalue('rType','0')
bType=form.getvalue('bType','0')
eType=form.getvalue('eType','0')
epno=form.getvalue('epno','0')
pType=form.getvalue('pType','0') 
roomNo=form.getvalue('roomNo','0')
totalPayment=form.getvalue('totalPayment',0000.0000)
upgradeC=form.getvalue('upgradeC','0')
eventBased=form.getvalue('eventBased','0')



print "Content-type:text/html\r\n\r\n"
print "<html><head>"
print "<title>Hello | Create New Customer</title>"
print "<meta charset='utf-8'>"
print "<meta name='viewport' content='width=device-width, initial-scale=1'>"
print "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>"
print "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>"
print "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>"
  
print "</head><body>"
print "<nav class='navbar navbar-default'>"
print "<div class='container-fluid'>"
print "<div class='navbar-header'>"
print "<a class='navbar-brand' href='#'>Sample Hotel</a>"
print "</div>"
print "<ul class='nav navbar-nav'>"
print "<li><a href='./home.html'>Home</a></li>"
print "<li class='active'><a href='./AddCustomer.html'>Add Customer</a></li>"
print "<li><a href='./ViewCustomer.html'>View Customer</a></li>"
print "</ul>"
print "</div>"
print "</nav>"


try:
	config = ConfigParser.ConfigParser()
	config.readfp(open(r'server.conf'))

	
	con = MySQLdb.connect(config.get('Database','host'),
						 config.get('Database','user'),
						 config.get('Database','passwd'),
						 config.get('Database', 'db'))

	
	cur = con.cursor()
	cur.execute("select COUNT(*) from Customers where RoomNo="+roomNo+" and date(StartDate) >= date '"+sdate+"' and date(EndDate) <= date '"+edate+"'")
	result=cur.fetchone()

	if(result[0]!=0):
		print "<div class='container'>"
		print "<div class='alert alert-danger'>"
		print "<strong>Error!</strong> There already exist a reservation with the same details;"
		print "</div>"
		print "<a href='./AddCustomer.html' class='btn btn-info' role='button'>Return to Home</a>"
		print "</div>"
		
	else:

			#region Select Room
		room_type="Select RoomID from BDM_Final.Rooms where RoomType='"+rType+"';"
		cur.execute(room_type)
		room_result=cur.fetchone()
		if room_result is not None:
			roo=room_result[0]
		else:
			roo=0;




		#reigon select Event
		event_type="Select EventID from Events where EventName='"+eType+"';";
		cur.execute(event_type)
		event_result=cur.fetchone();
		if event_result is not None:
			eve=event_result[0]
		else:
			eve=0;


		

		insert_query="INSERT INTO `BDM_Final`.`Customers`"
		insert_query+="(`CustomerName`,"
		insert_query+="`ContactNo`,"
		insert_query+="`IsEventBased`,"
		insert_query+="`RoomID`,"
		insert_query+="`NoOfGuest`,"
		insert_query+="`NoOfParticipants`,"
		insert_query+="`EventID`,"
		insert_query+="`StartDate`,"
		insert_query+="`EndDate`,"
		insert_query+="`RoomNo`,"
		insert_query+="`CustDuration(InDays)`)"
		insert_query+="VALUES"
		insert_query+="('"+cname+"',"
		insert_query+="'"+pno+"',"
		insert_query+=""+eventBased+","
		insert_query+="'"+str(roo)+"',"
		insert_query+=""+guestno+","
		insert_query+=""+epno+","
		insert_query+="'"+str(eve)+"',"
		insert_query+="'"+sdate+"',"
		insert_query+="'"+edate+"',"
		insert_query+=""+roomNo+","
		insert_query+="'29 Days');";

		# insert_query="INSERT INTO `BDM_Final`.`Customers`"
			# insert_query+="(`CustomerName`,"
			# insert_query+="`ContactNo`,"
			# insert_query+="`IsEventBased`,"
			# insert_query+="`RoomID`,"
			# insert_query+="`NoOfGuest`,"
			# insert_query+="`NoOfParticipants`,"
			# insert_query+="`EventID`,"
			# insert_query+="`StartDate`,"
			# insert_query+="`EndDate`,"
			# insert_query+="`RoomNo`,"
			# insert_query+="`CustDuration(InDays)`)"
			# insert_query+="VALUES"
			# insert_query+="('Test',"
			# insert_query+="'54688',"
			# insert_query+="0,"
			# insert_query+="0,"
			# insert_query+="72,"
			# insert_query+="41,"
			# insert_query+="0,"
			# insert_query+="'2017-12-15',"
			# insert_query+="'2017-12-02',"
			# insert_query+="250,"
			# insert_query+="'29 Days');"

			# print insert_query

			# Use all the SQL you like
		
		cur.execute(insert_query)
		con.commit()

		#insert into Payment
		cust_type="Select Max(CustomerID) from Customers;"
		cur.execute(cust_type)
		cust_result=cur.fetchone();
		if cust_result is not None:
			curesult=int(cust_result[0])
		else:
			curesult=0;
		

		insert_payment="Insert into Payment (CustomerID,PaymentMode,TotalAmount)"
		insert_payment+="values("+str(curesult)+",'"+pType+"',"+str(totalPayment)+")"
		cur.execute(insert_payment)
		con.commit()

		payment_type="Select Max(PaymentID) from Payment;"
		cur.execute(payment_type)
		payment_result=cur.fetchone();
		if payment_result is not None:
			payresult=int(payment_result[0])
		else:
			payresult=0;


		insert_reservation="Insert into Reservation (CustomerID,AdminID,PaymentID,EventID)"
		insert_reservation+="values("+str(curesult)+",'1',"+str(payresult)+","+str(eve)+");"
		cur.execute(insert_reservation)
		con.commit()


		
		print "<div class='container'>"
		print "<div class='alert alert-success'>"
		print "<strong>Success!</strong> New Reservation was created."
		print "</div>"
		print "<a href='./AddCustomer.html' class='btn btn-info' role='button'>Return to Home</a>"
		print "</div>"


except _mysql.Error, e:
	print "<div class='container'>"
	print "<div class='alert alert-danger'>"
	print "<strong>Error!</strong> "+str(e.args[0])+","+str(e.args[1]);
	print "</div>"
	print "<a href='./AddCustomer.html' class='btn btn-info' role='button'>Return to Home</a>"
	print "</div>"
	# print "Error %d: %s" % (e.args[0], e.args[1])
	sys.exit(1)

else:
	con.close()

print '</body>'
print '</html>'
			
			