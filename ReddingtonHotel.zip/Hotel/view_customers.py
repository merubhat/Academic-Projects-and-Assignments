#!/usr/bin/python
# -*- coding: utf-8 -*-

import cgi
import _mysql
import sys
import ConfigParser
import MySQLdb


form=cgi.FieldStorage()
sdate=form.getvalue('sdate','2017-01-01')
edate=form.getvalue('edate','2017-01-01')




print "Content-type:text/html\r\n\r\n"
print "<html><head>"
print "<title>Reddington Hotel | Reservation Details</title>"
print "<meta charset='utf-8'>"
print "<meta name='viewport' content='width=device-width, initial-scale=1'>"
print "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>"
print "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>"
print "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>"
  
print "</head><body>"
print "<nav class='navbar navbar-default'>"
print "<div class='container-fluid'>"
print "<div class='navbar-header'>"
print "<a class='navbar-brand' href='#'>Reddington Hotel</a>"
print "</div>"
print "<ul class='nav navbar-nav'>"
print "<li><a href='./home.html'>Home</a></li>"
print "<li><a href='./AddCustomer.html'>Add Customer</a></li>"
print "<li class='active'><a href='./ViewCustomer.html'>View Customer</a></li>"
print "</ul>"
print "</div>"
print "</nav>"


try:
    config = ConfigParser.ConfigParser()
    config.readfp(open(r'server.conf'))

    
    con = MySQLdb.connect(config.get('Database','host'),
                         config.get('Database','user'),
                         config.get('Database','passwd'),
                         config.get('Database', 'db'))

    
    cur = con.cursor()
    # cur.execute("select C.CustomerID,C.CustomerName,E.EventName,R.RoomType,C.StartDate,C.EndDate,DateDiff(C.EndDate,C.StartDate) as DurationOfStay from Customers C,Events E,Rooms R Where C.EventID=E.EventID and C.RoomID=R.RoomID and date(C.StartDate) >= date '"+sdate+"' and date(C.EndDate) <= date '"+edate+"'"")";
    search_query="select C.CustomerID,C.CustomerName,E.EventName,R.RoomType,C.StartDate,C.EndDate,P.PaymentMode,P.TotalAmount, ";
    search_query+="DateDiff(C.EndDate,C.StartDate) as DurationOfStay from Customers C,Events E,Rooms R, Payment P ";
    search_query+="Where C.EventID=E.EventID and C.RoomID=R.RoomID and P.CustomerID=C.CustomerID and date(C.StartDate) >='"+sdate+"' and date(C.EndDate) <='"+edate+"'";
    
    cur.execute(search_query)
    results = cur.fetchall()
    num_fields = len(cur.description)
    columns=cur.description
    col_names = [i[0] for i in cur.description]
        

    if results is not None:
        print "<div class='container'>"
        print "<table class='table table-bordered table-inverse'>"
        print "<thead>"
        print "<tr>"
        for c in col_names:
            print "<th>"
            print c
            print "</th>"
        print "</tr>"
        print "</thead>"
        print "<tbody>"
        for row in results:
            print "<tr>"
            print "<th scope='row'>"+str(row[0])+"</th>"
            print "<th scope='row'>"+str(row[1])+"</th>"
            print "<th scope='row'>"+str(row[2])+"</th>"
            print "<th scope='row'>"+str(row[3])+"</th>"
            print "<th scope='row'>"+str(row[4])+"</th>"
            print "<th scope='row'>"+str(row[5])+"</th>"
            print "<th scope='row'>"+str(row[6])+"</th>"
            print "<th scope='row'>"+str(row[7])+"</th>"
            print "<th scope='row'>"+str(row[8])+"</th>"
            print "</tr>"
        print "</tbody>"
        print "</table>"


    else:
        print "<div class='container'>"
        print "<div class='alert alert-success'>"
        print "<strong>Error!</strong> There is no reservation for this date"
        print "</div>"
        print "<a href='./AddCustomer.html' class='btn btn-info' role='button'>Return to Home</a>"
        print "</div>"


except _mysql.Error, e:
    print "<div class='container'>"
    print "<div class='alert alert-danger'>"
    print "<strong>Error!</strong> "+str(e.args[0])+","+str(e.args[1]);
    print "</div>"
    print "<a href='./AddCustomer.html' class='btn .btn-danger' role='button'>Return to Home</a>"
    print "</div>"
    # print "Error %d: %s" % (e.args[0], e.args[1])
    sys.exit(1)

else:
    con.close()

print '</body>'
print '</html>'
            
            